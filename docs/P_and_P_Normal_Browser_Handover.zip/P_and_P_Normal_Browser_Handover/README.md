# P&P Browser Handover for Al

Start with IMPLEMENTATION_SPEC.md.

The HTML files are the approved/current visual references only. They are
not a replacement for the existing P&P Browser implementation or
authority model.

Do not use older mock-ups from the design process. This folder
intentionally contains only the selected references.

Before implementing the Practice Summary action labelled RESUME, confirm
its lifecycle semantics with Archie/P&P as noted in the specification.
